package calculadora;

/**
 *
 * @author lizbethpichardo
 * @version 1.0
 */
public class Main {
 public static void main(String[] args) {
		Calculadora calculadora = new Calculadora();
		calculadora.setVisible(true);
	}   
}

